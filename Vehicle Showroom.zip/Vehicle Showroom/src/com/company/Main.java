package com.company;

import com.company.engine.EngineType;
import com.company.vehicle.HeavyVehicle;
import com.company.vehicle.NormalVehicle;
import com.company.vehicle.SportsVehicle;
import com.company.vehicle.Vehicle;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static List<Vehicle> vehicleList = new ArrayList<>();


    public static void main(String[] args) {
        getDefaultVehicleList();
        showOptionMenu();

    }

    private static void showOptionMenu() {
        System.out.println("Vehicle Showroom");
        System.out.println(
                """
                        #1: Add new vehicle in showroom
                        #2: Remove any of the vehicle from showroom
                        #3: Show the vehicle lists with details
                        #4: Show the list of vehicles with current expected visitor count"""
        );

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number what you want: ");
        int option = scanner.nextInt();

        if (option == 1) {
            addNewVehicle();
        } else if (option == 2) {
            removeVehicle();
        } else if (option == 3) {
            showVehicleList(false);
        } else if (option == 4) {
            showVehicleList(true);
        }
    }

    private static void removeVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Vehicle Model :");
        String model = scanner.nextLine();
        for (Vehicle vehicle : vehicleList) {
            if (model.equals(vehicle.getModelNumber())) {
                vehicleList.remove(vehicle);
                System.out.println(model + " has removed");
                showOptionMenu();
                return;
            }
        }

        System.out.println("This vehicle not found");
        showOptionMenu();
    }

    private static void addNewVehicle() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter vehicle Details");

        System.out.print("Vehicle Model :");
        String model = scanner.nextLine();

        System.out.print("Vehicle Engine Power :");
        String enginePower = scanner.nextLine();

        System.out.print("Vehicle Tire Size :");
        String tireSize = scanner.nextLine();

        System.out.print("Vehicle Engine Type :");
        String val = scanner.nextLine();
        EngineType engineType = ((val.equals(EngineType.GAS.name())) ||
                (val.equals(EngineType.OIL.name())) || val.equals(EngineType.DIESEL.name())) ? EngineType.valueOf(val)
                : EngineType.EMPTY;

        Vehicle vehicle = null;
        if (engineType == EngineType.OIL) {
            System.out.print("Vehicle turbo :");
            String turbo = scanner.nextLine();
            vehicle = new SportsVehicle(model, turbo, enginePower, tireSize);
        } else if (engineType == EngineType.DIESEL) {
            System.out.print("Vehicle weight :");
            String weight = scanner.nextLine();
            vehicle = new HeavyVehicle(weight, model, enginePower, tireSize);
        } else {
            vehicle = new NormalVehicle(model, engineType, enginePower, tireSize);
        }
        vehicle.increaseVisitorsCount();
        vehicleList.add(vehicle);
        System.out.println("Vehicle added");
        showVehicleList(true);
    }

    private static void showVehicleList(boolean showVisitors) {
        if (vehicleList.isEmpty()) {
            System.out.println("Currently no vehicle found in showroom");

        } else {
            if (showVisitors) {
                System.out.format("%25s%20s%16s%16s%16s", "Model Number", "Engine Power", "Engine type", "Tire Size", "Visitors");
                for (Vehicle vehicle : vehicleList) {
                    System.out.println();
                    System.out.format("%25s%20s%16s%16s%16s", vehicle.getModelNumber(), vehicle.getEnginePower(), vehicle.getEngineType().name(), vehicle.getTireSize(), vehicle.getVisitors());
                }
            } else {
                System.out.format("%25s%20s%16s%16s", "Model Number", "Engine Power", "Engine type", "Tire Size");
                for (Vehicle vehicle : vehicleList) {
                    System.out.println();
                    System.out.format("%25s%20s%16s%16s", vehicle.getModelNumber(), vehicle.getEnginePower(), vehicle.getEngineType().name(), vehicle.getTireSize());
                }
            }
        }
    }

    private static void getDefaultVehicleList() {
        NormalVehicle normalVehicle = new NormalVehicle("HV3", EngineType.GAS, "14k/w", "140/80");
        SportsVehicle sportsVehicle = new SportsVehicle("Yhamaha R15 v3", "14bhp", "19K/W", "130/80");
        HeavyVehicle heavyVehicle = new HeavyVehicle("775 kg", "2018 Renault Kwid RXL",
                "67bhp@5500rpm", "165/70 R14");

        vehicleList.add(normalVehicle);
        vehicleList.add(heavyVehicle);
        vehicleList.add(sportsVehicle);
    }

}
