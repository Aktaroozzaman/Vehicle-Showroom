package com.company.vehicle;

import com.company.engine.EngineType;

public class SportsVehicle extends Vehicle{
    private String turbo;

    public SportsVehicle(String modelNumber, String turbo,
                         String enginePower, String tireSize) {
        super(modelNumber, EngineType.OIL, enginePower, tireSize);
        this.turbo = turbo;
    }
}
