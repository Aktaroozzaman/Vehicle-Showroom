package com.company.vehicle;

import com.company.engine.EngineType;

public class NormalVehicle extends Vehicle{
    public NormalVehicle(String modelNumber, EngineType engineType, String enginePower, String tireSize) {
        super(modelNumber, engineType, enginePower, tireSize);
    }
}
