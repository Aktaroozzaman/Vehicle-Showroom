package com.company.vehicle;

import com.company.engine.EngineType;

public class HeavyVehicle extends Vehicle{
    private String weight;

    public HeavyVehicle(String weight, String modelNumber, String enginePower, String tireSize) {
        super(modelNumber, EngineType.DIESEL, enginePower, tireSize);
        this.weight = weight;
    }
}
