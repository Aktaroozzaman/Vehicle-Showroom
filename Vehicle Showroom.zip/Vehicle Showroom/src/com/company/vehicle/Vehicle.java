package com.company.vehicle;

import com.company.engine.EngineType;

public abstract class Vehicle {
    private final String modelNumber;
    private final EngineType engineType;
    private final String enginePower;
    private final String tireSize;
    private int visitors = 30;

    public Vehicle(String modelNumber, EngineType engineType, String enginePower, String tireSize) {
        this.modelNumber = modelNumber;
        this.engineType = engineType;
        this.enginePower = enginePower;
        this.tireSize = tireSize;
    }

    public void increaseVisitorsCount(){
        visitors += 20;
    }

    public int getVisitors() {
        return visitors;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public EngineType getEngineType() {
        return engineType;
    }

    public String getEnginePower() {
        return enginePower;
    }

    public String getTireSize() {
        return tireSize;
    }
}
