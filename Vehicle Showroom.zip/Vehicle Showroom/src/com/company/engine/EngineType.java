package com.company.engine;

public enum EngineType {
    OIL, GAS, DIESEL, EMPTY
}
